using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum ItemType { useabel,Weapon,Other}
[CreateAssetMenu(fileName ="New Item",menuName = "Charactor Stats/Item Data")]
public class ItemData_SO : ScriptableObject
{
    public ItemType itemType;
    public string itemName;
    public Sprite itemIcon;
    public int itenAmo;
    [TextArea]
    public string description = "";

    public bool stackable;

    [Header("Useable")]
    public UseableItem_SO Useable;

    [Header("Weapon")]
    public GameObject weaponprefabe;
    public AttackData_SO weaponAttackData;
    public AnimatorOverrideController weaponAnimator;

}
