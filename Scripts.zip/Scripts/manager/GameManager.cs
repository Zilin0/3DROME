using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class GameManager : Singleton<GameManager>
{
    public characterStats playerStats;

    private CinemachineFreeLook followCam;

    List<IEndGame> endGames = new List<IEndGame>();

    protected override void Awake()
    {
        base.Awake();
        DontDestroyOnLoad(this);
    }

    public void RigisterPlayer(characterStats player)
    {
        playerStats = player;

        followCam = FindObjectOfType<CinemachineFreeLook>();
        if (followCam != null)
        {
            followCam.Follow = playerStats.transform.GetChild(2);
            followCam.LookAt = playerStats.transform.GetChild(2);
        }
    }

    public void AddObserver(IEndGame observer)
    {
        endGames.Add(observer);
    }

    public void RemoveObserver(IEndGame observer)
    {
        endGames.Remove(observer);
    }

    public void NotifyObservers()
    {
        foreach(var observer in endGames)
        {
            observer.EndNotify();
        }
    }

    public Transform GetEntrance()
    {
        foreach(var item in FindObjectsOfType<TransitionDestination>())
        {
            if (item.destinationTag == TransitionDestination.DestinationTag.Start)
                return item.transform;
        }
        return null;
    }
}
