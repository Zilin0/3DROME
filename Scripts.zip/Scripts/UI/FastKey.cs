 using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FastKey : MonoBehaviour
{
    public KeyCode fastKey;
    private SlotHoler currentSlotHolder;

    void Awake()
    {
        currentSlotHolder = GetComponent<SlotHoler>();

    }

    void Update()
    {
        if (Input.GetKeyDown(fastKey) && currentSlotHolder.itemUI.GetItem())
        {
            currentSlotHolder.UseItem();
        }
    }
}
