using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TransitionDestination : MonoBehaviour
{
    public enum DestinationTag
    {
        Start,None,Lobby,BarA,BarB,GrainSilosA, GrainSilosB
    }

    public DestinationTag destinationTag;
}
