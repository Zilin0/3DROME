using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.EventSystems;

public class MouseManager : Singleton<MouseManager>
{
    
    public Texture2D point, door, attack, target, arrow;

    RaycastHit hitInfo;
    public event Action<Vector3> OnMouseClicked;
    public event Action<GameObject> OnEnemyClicked;

    protected override void Awake()
    {
        base.Awake();
        DontDestroyOnLoad(this);
    }
    void Update()
    {
        SetCursorTexture();
        if (InteractWithUI()) return;
        MouseControl();
    }

    void SetCursorTexture()
    {
       Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (InteractWithUI())
        {
            Cursor.SetCursor(point, new Vector2(50, 50), CursorMode.Auto);
            return;
        }
        if (Physics.Raycast(ray,out hitInfo))
        {
            //texture
            switch (hitInfo.collider.gameObject.tag)
            {
                case "Ground":
                    Cursor.SetCursor(target, new Vector2(50, 50), CursorMode.Auto);
                    break;
                //case "Player":
                    //Cursor.SetCursor(arrow, new Vector2(50, 50), CursorMode.Auto);
                   // break;
                case "Protector":
                    Cursor.SetCursor(attack, new Vector2(50, 50), CursorMode.Auto);
                    break;
                case "Door":
                    Cursor.SetCursor(door, new Vector2(50, 50), CursorMode.Auto);
                    break;
                case "Item":
                    Cursor.SetCursor(point, new Vector2(50, 50), CursorMode.Auto);
                    break;
                default:
                    Cursor.SetCursor(arrow, new Vector2(50, 50), CursorMode.Auto);
                    break;
            }
        }
        
    }

    void MouseControl()
    {
        if(Input.GetMouseButtonDown(0) && hitInfo.collider != null)
        {
            if (hitInfo.collider.gameObject.CompareTag("Ground"))
                OnMouseClicked?.Invoke(hitInfo.point);
            if (hitInfo.collider.gameObject.CompareTag("Protector"))
                OnEnemyClicked?.Invoke(hitInfo.collider.gameObject);
            if (hitInfo.collider.gameObject.CompareTag("Door"))
                OnMouseClicked?.Invoke(hitInfo.point);
            if (hitInfo.collider.gameObject.CompareTag("Item"))
                OnMouseClicked?.Invoke(hitInfo.point);
        }
    }

    bool InteractWithUI()
    {
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
        {
            return true;
        }
        else return false;
    }
}
