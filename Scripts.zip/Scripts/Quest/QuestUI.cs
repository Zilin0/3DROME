using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestUI : Singleton<QuestUI>
{
    [Header("Element")]
    public GameObject questPanel;
    //public ItemTip tooltip;
    bool isOpen;

    [Header("Quest Name")]
    public RectTransform questListTransfor;
    public QuestNameButton questNameButton;

    [Header("Text content")]
    public Text questContentText;

    [Header("Requirement")]
    public RectTransform requireTransform;
    public QuestRequitement requirement;

    [Header("Reward Panel")]
    public RectTransform rewardTransform;
    public ItemUI rewardUI;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            isOpen = !isOpen;
            questPanel.SetActive(isOpen);
            questContentText.text = "";
            SetQuestList();
        }
    }

    public void SetQuestList()
    {
        foreach(Transform item in questListTransfor)
        {
            Destroy(item.gameObject);
        }
        foreach (Transform item in rewardTransform)
        {
            Destroy(item.gameObject);
        }
        foreach (Transform item in requireTransform)
        {
            Destroy(item.gameObject);
        }
        foreach(var task in QuestManager.Instance.tasks)
        {
            var newTask = Instantiate(questNameButton, questListTransfor);
            newTask.SetupNameButton(task.questData);
            newTask.questContentText = questContentText;
        }
    }

    public void SetUpRequireList(QuestData_SO questDate)
    {
        foreach (Transform item in requireTransform)
        {
            Destroy(item.gameObject);

        }
        foreach(var require in questDate.questRequires)
        {
            var q = Instantiate(requirement, rewardTransform);
            if (questDate.isFinished)
                q.SetupRequirement(require.name, questDate.isFinished);
            else
                q.SetupRequirement(require.name, require.requireAmount, require.currentAmount);
        }
    }

    public void SetuoRewardItem(ItemData_SO itemData,int amount)
    {
        var item = Instantiate(rewardUI, rewardTransform);
        item.SetUpItemUI(itemData, amount);
    }
}
