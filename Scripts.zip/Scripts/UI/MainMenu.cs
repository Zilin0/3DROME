using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    Button newGame;
    Button continuGame;
    Button exitGame;

    Button First;
    Image Firstinfo;
    bool isopen = false;

    void Awake()
    {
        newGame = transform.GetChild(1).GetComponent<Button>();
        continuGame = transform.GetChild(2).GetComponent<Button>();
        exitGame = transform.GetChild(3).GetComponent<Button>();
        First = transform.GetChild(4).GetComponent<Button>();
        Firstinfo = transform.GetChild(5).GetComponent<Image>();

        newGame.onClick.AddListener(NewGame);
        continuGame.onClick.AddListener(ContinueGame);
        exitGame.onClick.AddListener(QuitGame);
        
    }
    private void Update()
    {
        First.onClick.AddListener(SetInfo);
        isopen = !isopen;
    }

    void SetInfo()
    {
        Firstinfo.gameObject.SetActive(!isopen);
    }
    void NewGame()
    {
        PlayerPrefs.DeleteAll();
        SceneController.Instance.TransitionToFirst();
    }
    void ContinueGame()
    {
        SceneController.Instance.TransitionToLoadGame();
    }
    private void QuitGame()
    {
        Application.Quit();
        Debug.Log("Exit");
    }
}
