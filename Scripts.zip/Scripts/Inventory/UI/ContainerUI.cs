using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContainerUI : MonoBehaviour
{
    public SlotHoler[] slotHolers;

    public void RefreshUI()
    {
        for(int i = 0; i < slotHolers.Length; i++)
        {
            slotHolers[i].itemUI.Index = i;
            slotHolers[i].UpdateItem();
        }
    }
}


