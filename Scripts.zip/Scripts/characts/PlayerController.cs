using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PlayerController : MonoBehaviour
{
    private NavMeshAgent agent;
    private Animator anim;
    private characterStats characterstats;
    private GameObject attackTarget;
    private float lastAttackTime;
    private bool isDeath;

    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        
        anim = GetComponent<Animator>();
        
        characterstats = GetComponent<characterStats>();

        
    }
    void OnEnable()
    {
        MouseManager.Instance.OnMouseClicked += MoveToTarget;
        MouseManager.Instance.OnEnemyClicked += EventAttack;
        GameManager.Instance.RigisterPlayer(characterstats);
    }
    void Start()
    {
        SaveManager.Instance.LoadPlayerData();
    }
   
    void OnDisable()
    {
        if (!MouseManager.IsInitialzed) return;
        MouseManager.Instance.OnMouseClicked -= MoveToTarget;
        MouseManager.Instance.OnEnemyClicked -= EventAttack;

    }

    void Update()
    {
        
        isDeath = characterstats.CurrentHealth == 0; 
        if (isDeath)
            GameManager.Instance.NotifyObservers();

        SwitchAnimation();

        lastAttackTime -= Time.deltaTime;
    }

    private void SwitchAnimation()
    {
        anim.SetFloat("Speed", agent.velocity.sqrMagnitude);
        anim.SetBool("Death", isDeath);
    }
    public void MoveToTarget(Vector3 target)
    {
        StopAllCoroutines();
        if (isDeath) return;
        
        agent.isStopped = false;
        agent.destination = target;
    }
    private void EventAttack(GameObject target)
    {
        if (isDeath) return;

        if (target != null)
        {
            attackTarget = target;
            characterstats.isCritical = UnityEngine.Random.value < characterstats.attackData.criticalChance;
            StartCoroutine(MoveToAttack());
        }
    }
    IEnumerator MoveToAttack()
    {
        agent.isStopped = false;

        transform.LookAt(attackTarget.transform);

        while (Vector3.Distance(attackTarget.transform.position,transform.position) > characterstats.attackData.attackRange)
        {
            agent.destination = attackTarget.transform.position;
            yield return null;
        }

        agent.isStopped = true;
        //attack
        if (lastAttackTime < 0)
        {
            anim.SetBool("Critical", characterstats.isCritical);
            anim.SetTrigger("Attack");
            //CD
            lastAttackTime = characterstats.attackData.coolDown;
        }
    }

    //animation event
    private void Hit()
    {
        if (attackTarget != null)
        {
            var targetStats = attackTarget.GetComponent<characterStats>();
            targetStats.GetDamage(characterstats, targetStats);
        }
    }
}
