using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestRequitement : MonoBehaviour
{
    private Text requireName;
    private Text progressNumber;

    private void Awake()
    {
        requireName = GetComponent<Text>();
        progressNumber = transform.GetChild(0).GetComponent<Text>();
    }
    public void SetupRequirement(string name,int  amunt,int currountammount)
    {
        requireName.text = name;
        progressNumber.text = currountammount.ToString() + "/" + amunt.ToString();
    }
    public void SetupRequirement(string name, bool isFinished)
    {
        if (isFinished)
        {
            requireName.text = name;
            progressNumber.text = "finishen";
            requireName.color = Color.gray;
            progressNumber.color = Color.gray;
        }
    }
}
