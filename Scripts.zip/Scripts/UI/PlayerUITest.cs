using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerUITest : MonoBehaviour
{
    public GameObject healthUI;
    public Transform UIPoint;
    public bool alwaysVisible;
    public float visibleTime;
    Image healthSlider;
    Image ExpSlider;
    Transform UIbar;
    Transform cam;

    characterStats currentStats;

    void Awake()
    {
        currentStats = GetComponent<characterStats>();
        currentStats.UpdateHPUIOnAttack += UpdateHealthBar;
    }

    void OnEnable()
    {
        cam = Camera.main.transform;

        foreach (Canvas canvas in FindObjectsOfType<Canvas>())
        {
            if (canvas.renderMode == RenderMode.WorldSpace)
            {
                UIbar = Instantiate(healthUI, canvas.transform).transform;
                healthSlider = UIbar.GetChild(0).GetComponent<Image>();
                UIbar.gameObject.SetActive(alwaysVisible);
            }
        }
    }
    private void UpdateHealthBar(int currentHealth, int MaxHealth)
    {
        if (currentHealth <= 0)
            Destroy(UIbar.gameObject);
        UIbar.gameObject.SetActive(true);

        float sliderPercent = (float)currentHealth / MaxHealth;
        healthSlider.fillAmount = sliderPercent;
    }

    void LateUpdate()
    {
        if (UIbar != null)
        {
            UIbar.position = UIPoint.position;
            UIbar.forward = -cam.forward;
        }
    }
}