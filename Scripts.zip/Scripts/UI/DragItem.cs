using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

[RequireComponent(typeof(ItemUI))]
public class DragItem : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{

    ItemUI currentItemUI;
    SlotHoler currentHolder;
    SlotHoler targetHolder;

    void Awake()
    {
        currentItemUI = GetComponent<ItemUI>();
        currentHolder = GetComponentInParent<SlotHoler>();
    }
    public void OnBeginDrag(PointerEventData eventData)
    {
        InventoryManager.Instance.currentDrag = new InventoryManager.DragData();
        InventoryManager.Instance.currentDrag.originalHolder = GetComponentInParent<SlotHoler>();
        InventoryManager.Instance.currentDrag.originalParent = (RectTransform)transform.parent;
        //save basedata
        transform.SetParent(InventoryManager.Instance.dragCanvas.transform, true);

    }

    public void OnDrag(PointerEventData eventData)
    {
        //floww mouse
        transform.position = eventData.position;
    }
    

    public void OnEndDrag(PointerEventData eventData)
    {
        //put item
        if (EventSystem.current.IsPointerOverGameObject())
        {
            if (InventoryManager.Instance.CheckInInventoryUI(eventData.position)|| 
                InventoryManager.Instance.CheckInOtherUI(eventData.position)|| 
                InventoryManager.Instance.CheckInWeaponUI(eventData.position))
            {
                if (eventData.pointerEnter.gameObject.GetComponent<SlotHoler>())
                    targetHolder = eventData.pointerEnter.gameObject.GetComponent<SlotHoler>();
                else
                    targetHolder = eventData.pointerEnter.gameObject.GetComponentInParent<SlotHoler>();
                if (targetHolder != InventoryManager.Instance.currentDrag.originalHolder)
                {
                    switch (targetHolder.slotType)
                    {

                        case SlotTyepe.BAG:
                            SwapItem();
                            break;
                        case SlotTyepe.OTHER:
                            if (currentItemUI.Bag.items[currentItemUI.Index].itemData.itemType == ItemType.useabel)
                                SwapItem();
                            break;
                        case SlotTyepe.WEAPON:
                            if (currentItemUI.Bag.items[currentItemUI.Index].itemData.itemType == ItemType.Weapon)
                                SwapItem();
                            break;

                    }
                }             
                currentHolder.UpdateItem();
                targetHolder.UpdateItem();

            }
        }
        transform.SetParent(InventoryManager.Instance.currentDrag.originalParent);

        RectTransform t = transform as RectTransform;

        t.offsetMax = -Vector2.one * 5;
        t.offsetMin = Vector2.one * 5;
    }

    public void SwapItem()
    {
        var targetItem = targetHolder.itemUI.Bag.items[targetHolder.itemUI.Index];
        var tempItem = currentHolder.itemUI.Bag.items[currentHolder.itemUI.Index];

        bool isSaameItem = tempItem.itemData == targetItem.itemData;

        if (isSaameItem && targetItem.itemData.stackable)
        {
            targetItem.amount += tempItem.amount;
            tempItem.itemData = null;
            tempItem.amount = 0;
        }
        else
        {
            currentHolder.itemUI.Bag.items[currentHolder.itemUI.Index] = targetItem;
            targetHolder.itemUI.Bag.items[targetHolder.itemUI.Index] = tempItem;
        }
    }

}
