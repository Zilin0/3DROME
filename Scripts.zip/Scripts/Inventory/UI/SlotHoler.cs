using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public enum SlotTyepe { BAG,WEAPON,OTHER}
public class SlotHoler : MonoBehaviour,IPointerClickHandler,IPointerEnterHandler,IPointerExitHandler
{
    public SlotTyepe slotType;
    public ItemUI itemUI;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.clickCount % 2 == 0)
        {
            UseItem();
        }
    }

    public void UseItem()
    {
        if(itemUI.GetItem()!=null)
            if (itemUI.GetItem().itemName== "Wine" && itemUI.Bag.items[itemUI.Index].amount > 0)
            {
                GameManager.Instance.playerStats.ApplyHealth(itemUI.GetItem().Useable.healthPoint);

                itemUI.Bag.items[itemUI.Index].amount -= 1;

                QuestManager.Instance.UpdateQuestProgreaa(itemUI.GetItem().itemName, -1);
            }
        UpdateItem();
    }

    public void UpdateItem()
    {
        switch (slotType)
        {
            case SlotTyepe.BAG:
                itemUI.Bag = InventoryManager.Instance.inventoryDatas;
                break;
            case SlotTyepe.WEAPON:
                itemUI.Bag = InventoryManager.Instance.weaponDatas;
                if (itemUI.Bag.items[itemUI.Index].itemData!= null)
                {
                    GameManager.Instance.playerStats.ChangeWeapon(itemUI.Bag.items[itemUI.Index].itemData);
                }
                else
                {
                    GameManager.Instance.playerStats.UnEquipWeapon();
                }
                break;
            case SlotTyepe.OTHER:
                itemUI.Bag = InventoryManager.Instance.otherDatas;
                break;
        }

        var item = itemUI.Bag.items[itemUI.Index];
        itemUI.SetUpItemUI(item.itemData, item.amount);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (itemUI.Bag.items[itemUI.Index].itemData)
        {
            InventoryManager.Instance.tooltip.SetupTooltip(itemUI.Bag.items[itemUI.Index].itemData);
            InventoryManager.Instance.tooltip.gameObject.SetActive(true);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        InventoryManager.Instance.tooltip.gameObject.SetActive(false);
    }

    void OnDisable()
    {
        InventoryManager.Instance.tooltip.gameObject.SetActive(false);
    }
}
