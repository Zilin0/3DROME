using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public enum ProtectorStates {GUARD,PATROL,CHASE,DEAD}
[RequireComponent(typeof(NavMeshAgent))]
[RequireComponent(typeof(characterStats))]

public class ProtectorController : MonoBehaviour,IEndGame
{
    private ProtectorStates protectorstates;

    private NavMeshAgent agent;
    private Animator anim;
    private Collider coll;
    private characterStats characterstats;

    [Header("Basic Setting")]
    public float sightRadius;
    public bool isGuard;
    private float speed;
    protected GameObject attackTarget;
    public float lookatTime;
    private float remainlookatTime;
    private float lastAttackTime;
    private Quaternion guardRotation;

    [Header("Partol State")]
    public float patrolRange;
    private Vector3 patrolPoint;
    private Vector3 guardPoint;

    bool isRun;
    bool isChase;
    bool isFollow;
    protected bool isDead=false;
    bool playerDead;
    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        anim = GetComponent<Animator>();
        characterstats = GetComponent<characterStats>();
        coll = GetComponent<Collider>();
        speed = agent.speed;
        guardPoint = transform.position;
        guardRotation = transform.rotation;
        remainlookatTime = lookatTime;
        
     }
    void Start()
    {
        if (isGuard)
        {
            protectorstates = ProtectorStates.GUARD;
        }
        else
        {
            protectorstates = ProtectorStates.PATROL;
            GetNewChaesPoint();
        }
        GameManager.Instance.AddObserver(this);
    }
   /* void OnEnable()
    {
        GameManager.Instance.AddObserver(this);
    }*/
    void OnDisable()
    {
        if (!GameManager.IsInitialzed) return;
        GameManager.Instance.RemoveObserver(this);

        if (GetComponent<LootSpawner>() && isDead)
            GetComponent<LootSpawner>().Spawnloot();

        if (QuestManager.IsInitialzed && isDead)
        {
            QuestManager.Instance.UpdateQuestProgreaa(this.name, 1);
        }
    }


    void Update()
    {
        if (characterstats.CurrentHealth == 0)
            isDead = true;
        if (!playerDead)
        {
            SwitchStates();
            SwitchAnimation();
            lastAttackTime -= Time.deltaTime;
        }
        
    }

    void SwitchAnimation()
    {
        anim.SetBool("Run", isRun);
        anim.SetBool("Chase", isChase);
        anim.SetBool("Follow", isFollow);
        anim.SetBool("Critical", characterstats.isCritical);
        anim.SetBool("Death", isDead);
    }
    void SwitchStates()
    {
        if (isDead)
            protectorstates = ProtectorStates.DEAD;
        else if (FoundPlayer())
        {
            protectorstates = ProtectorStates.CHASE;
            
        }
        switch (protectorstates)
        {
            case ProtectorStates.GUARD:
                isChase = false;

                if (transform.position != guardPoint)
                {
                    isRun = true;
                    agent.isStopped = false;
                    agent.destination = guardPoint;

                    if (Vector3.Distance(guardPoint,transform.position) <= agent.stoppingDistance)
                    {
                        isRun = false;
                        transform.rotation = Quaternion.Lerp(transform.rotation,guardRotation,0.1f);
                    }
                }
                break;
            case ProtectorStates.PATROL:
                isChase = false;
                agent.speed = speed * 0.5f;

                if (Vector3.Distance(patrolPoint,transform.position )<= agent.stoppingDistance)
                {
                    isRun = false;
                    if (remainlookatTime > 0)
                        remainlookatTime -= Time.deltaTime;
                    else
                    GetNewChaesPoint();
                }
                else
                {
                    isRun = true;
                    agent.destination = patrolPoint;
                }
                break;
            case ProtectorStates.CHASE:
                isRun = false;
                isChase = true;

                agent.speed = speed;

                if (!FoundPlayer())
                {
                    isFollow = false;
                    if (remainlookatTime > 0)
                    {
                        agent.destination = transform.position;
                        remainlookatTime -= Time.deltaTime;
                    }
                    else if (isGuard)
                        protectorstates = ProtectorStates.GUARD;
                    else
                        protectorstates = ProtectorStates.PATROL;
                }
                else
                {
                    isFollow = true;
                    agent.isStopped = false;
                    agent.destination = attackTarget.transform.position;
                }
                if (TargetInAttackRange() || TargetInSkillRange())
                {
                    isFollow = false;
                    agent.isStopped = true;

                    if (lastAttackTime < 0)
                    {
                        lastAttackTime = characterstats.attackData.coolDown;

                        //*
                        characterstats.isCritical = Random.value < characterstats.attackData.criticalChance;
                        //attack
                        Attack();
                    }
                }
                break;
            case ProtectorStates.DEAD:
                coll.enabled = false;
                agent.radius = 0;
                Destroy(gameObject, 2f);
                break;
        }
    }

    void Attack()
    {
        transform.LookAt(attackTarget.transform);
        if (TargetInAttackRange())
        {
            //close
            anim.SetTrigger("Attack");
        }
        if (TargetInSkillRange())
        {
            //far
            anim.SetTrigger("Skill");

        }
    }

    bool FoundPlayer()
    {
        var colliders = Physics.OverlapSphere(transform.position,sightRadius);

        foreach(var target in colliders)
        {
            if (target.CompareTag("Player"))
            {
                attackTarget = target.gameObject;
                return true;
            }
        }
        attackTarget = null;
        return false;
    }

    bool TargetInAttackRange()
    {
        if (attackTarget != null)
            return Vector3.Distance(attackTarget.transform.position, transform.position) <= characterstats.attackData.attackRange;
        else
            return false;
    }
    bool TargetInSkillRange()
    {
        if (attackTarget != null)
            return Vector3.Distance(attackTarget.transform.position, transform.position) <= characterstats.attackData.skillRange;
        else
            return false;
    }
    void GetNewChaesPoint()
    {
        remainlookatTime = lookatTime;
        float randomX = Random.Range(-patrolRange, patrolRange);
        float randomZ = Random.Range(-patrolRange, patrolRange);

        Vector3 randomPoint = new Vector3(guardPoint.x + randomX, transform.position.y, guardPoint.z+randomZ);

        NavMeshHit hit;
        patrolPoint = NavMesh.SamplePosition(randomPoint, out hit, patrolRange, 1) ? hit.position : transform.position;
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, sightRadius);
    }

    //animation enent
    void Hit()
    {
        if (attackTarget != null && transform.IsFacingTarget(attackTarget.transform))
        {
            var targetStats = attackTarget.GetComponent<characterStats>();
            targetStats.GetDamage(characterstats, targetStats);
        }
    }

    public void EndNotify()
    {
        //win
        //stop move
        //stop agent
        isChase = false;
        isRun = false;
        playerDead = true;
        attackTarget = null;
    }
}


