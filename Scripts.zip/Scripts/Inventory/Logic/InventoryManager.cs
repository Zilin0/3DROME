using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventoryManager :Singleton<InventoryManager>
{
    public class DragData
    {
        public SlotHoler originalHolder;
        public RectTransform originalParent;
    }


    [Header("Inventory Data")]
    public inventoryData_SO inventoryDatas;
    public inventoryData_SO otherDatas;
    public inventoryData_SO weaponDatas;
    public inventoryData_SO inventoryTemplate;
    public inventoryData_SO otherTemplate;
    public inventoryData_SO weaponTemplate;


    [Header("ContainerS")]

    public ContainerUI inventoryUI;
    public ContainerUI otherUI;
    public ContainerUI weaponUI;

    [Header("Drag Canvas")]
    public Canvas dragCanvas;
    public DragData currentDrag;

    [Header("UI Panel")]
    public GameObject bagPanel;

    [Header("Tooltip")]
    public ItemTip tooltip;

    protected override void Awake()
    {
        base.Awake();
        if (inventoryTemplate != null)
            inventoryDatas = Instantiate(inventoryTemplate);
        if (otherTemplate != null)
            otherDatas = Instantiate(otherTemplate);
        if (weaponTemplate != null)
            weaponDatas = Instantiate(weaponTemplate);
    }
    bool isOpen = false;
    void Start()
    {
        LoadData();
        inventoryUI.RefreshUI();
        otherUI.RefreshUI();
        weaponUI.RefreshUI();
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.B))
        {
            isOpen = !isOpen;
            bagPanel.SetActive(isOpen);
        }
    }

    public void SaveData()
    {
        SaveManager.Instance.Save(inventoryDatas, inventoryDatas.name);
        SaveManager.Instance.Save(otherDatas, otherDatas.name);
        SaveManager.Instance.Save(weaponDatas, weaponDatas.name);
    }

    public void LoadData()
    {
        SaveManager.Instance.Load(inventoryDatas, inventoryDatas.name);
        SaveManager.Instance.Load(otherDatas, otherDatas.name);
        SaveManager.Instance.Load(weaponDatas, weaponDatas.name);
    }
    #region 
    public bool CheckInInventoryUI(Vector3 position)
    {
        for(int i = 0; i < inventoryUI.slotHolers.Length; i++)
        {
            RectTransform t = inventoryUI.slotHolers[i].transform as RectTransform;

            if (RectTransformUtility.RectangleContainsScreenPoint(t, position))
            {
                return true;
            }
        }
        return false;
    }
    public bool CheckInWeaponUI(Vector3 position)
    {
        for (int i = 0; i < weaponUI.slotHolers.Length; i++)
        {
            RectTransform t = weaponUI.slotHolers[i].transform as RectTransform;

            if (RectTransformUtility.RectangleContainsScreenPoint(t, position))
            {
                return true;
            }
        }
        return false;
    }
    public bool CheckInOtherUI(Vector3 position)
    {
        for (int i = 0; i < otherUI.slotHolers.Length; i++)
        {
            RectTransform t = otherUI.slotHolers[i].transform as RectTransform;

            if (RectTransformUtility.RectangleContainsScreenPoint(t, position))
            {
                return true;
            }
        }
        return false;
    }


    #endregion

    #region Quest
    public void CheckQuestItemInBag(string questItemname)
    {
        foreach(var item in inventoryDatas.items)
        {
            if (item.itemData != null)
            {
                if (item.itemData.itemName == questItemname)
                    QuestManager.Instance.UpdateQuestProgreaa(item.itemData.itemName, item.amount);
            }
        }

        foreach (var item in otherDatas.items)
        {
            if (item.itemData != null)
            {
                if (item.itemData.itemName == questItemname)
                    QuestManager.Instance.UpdateQuestProgreaa(item.itemData.itemName, item.amount);
            }
        }
    }
    #endregion

    public InventoryItem QuestItemInBag(ItemData_SO questItem)
    {
        return inventoryDatas.items.Find(i => i.itemData == questItem);
    }
    public InventoryItem QuestItemAction(ItemData_SO questItem)
    {
        return otherDatas.items.Find(i => i.itemData == questItem);
    }
}
