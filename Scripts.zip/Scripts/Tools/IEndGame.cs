
public interface IEndGame 
{
    void EndNotify();

}
