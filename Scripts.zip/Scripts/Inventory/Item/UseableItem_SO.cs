using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Item", menuName = "Charactor Stats/Useable Data")]
public class UseableItem_SO : ScriptableObject
{
    public int healthPoint;
}
