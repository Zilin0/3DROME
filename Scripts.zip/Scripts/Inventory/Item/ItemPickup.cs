using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    public ItemData_SO itemData;
    void OnTriggerEnter(Collider other)
    {

        if (other.CompareTag("Player"))
        {

            //if (itemData != null && InventoryManager.Instance.inventoryDatas != null)
            InventoryManager.Instance.inventoryDatas.AddItem(itemData, itemData.itenAmo);
            InventoryManager.Instance.inventoryUI.RefreshUI();
            //  GameManager.Instance.playerStats.EquipWeapon(itemData);

            QuestManager.Instance.UpdateQuestProgreaa(itemData.itemName, itemData.itenAmo);
            Destroy(gameObject);
        }
    }
}
